修复了Minecraft原版的一个bug，即中文标点符号占位仅为一格。

- 原作者：3TUSK
- 原帖地址：http://blog.tritusk.info/index.php/archives/8/
- Github：https://github.com/Team-AbCiv/FullwidthPunctuationFix
