# Hellfire 

![Hellfire Dust](item:betterwithmods:material@16)

Hellfire Dust can be created by a [Soul Sand Filter](../blocks/hopper_filters.md) in a [Hopper](../blocks/hopper.md)
