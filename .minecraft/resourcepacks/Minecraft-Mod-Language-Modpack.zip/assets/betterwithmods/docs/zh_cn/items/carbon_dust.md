# Carbon Dust

Coal Dust
![Coal Dust](item:betterwithmods:material:18)

Charcoal Dust
![Charcoal Dust](item:betterwithmods:material:27)