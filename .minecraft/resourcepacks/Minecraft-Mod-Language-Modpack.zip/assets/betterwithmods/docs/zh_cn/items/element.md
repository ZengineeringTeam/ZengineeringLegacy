# Heating Element

![Heating Element](item:betterwithmods:material@27)

A crafting component for the [Hibachi](../blocks/hibachi.md)