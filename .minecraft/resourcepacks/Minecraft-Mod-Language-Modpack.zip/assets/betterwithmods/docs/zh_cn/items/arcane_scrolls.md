# Arcane Scrolls
![Arcane Scrolls](item:betterwithmods:arcane_scroll)

An Arcane Scroll is paper embued with the powers or weaknesses of the mobs that dropped them.    
These powers can be harnessed through the use of the [Infernal Enchanter](../blocks/infernal_enchanter.md).

** Boss Enchants have a 100% drop chance.

* Bat - Feather Falling

* Blaze - Flame

* Creeper - Blast Protection

* Endermen - Silk Touch

* Ender Dragon - Sweeping **

* Ghast - Punch

* Guardian - Depth Strider

* Magma Cube - Fire Aspect

* Pig Zombie - Fire Protection 

* Polar Bear - Frost Walker

* Silverfish - Efficiency

* Skeleton - Projectile Protection

* Skeleton (While in the Nether) - Infinity

* Slime - Protection

* Spider - Bane of Arthropods

* Squid - Respiration

* Witch - Aqua Affinity

* Wither - Knockback **

* Zombie - Smite

* Sharpness, Looting, Unbreaking, Fortune, Power, Luck of the Sea, Binding Curse and Vanishing Curse are not in yet, soon (tm)  
