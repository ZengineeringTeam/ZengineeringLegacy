# Dynamite

![Dynamite](item:betterwithmods:dynamite)

Dynamite is a handheld explosive created using [Blasting Oil](blasting_oil.md). To use it you need a Flint and Steel in your inventory to light it, right click to throw.

Tip: try throwing it in a large body of water. (Best results with the Hardcore Buoyancy mod installed) 