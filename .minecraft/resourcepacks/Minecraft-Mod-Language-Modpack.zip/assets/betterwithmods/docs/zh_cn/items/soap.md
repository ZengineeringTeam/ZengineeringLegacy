# Soap

![Soap](item:betterwithmods:material@50)

![Soap Block](block:betterwithmods:aesthetic@10)

Soap is able to remove tough stains from blocks, such as the [Chopping Block](../blocks/chopping_block.md) or Sticky Pistons.

Make sure not to drop it, though. ;)