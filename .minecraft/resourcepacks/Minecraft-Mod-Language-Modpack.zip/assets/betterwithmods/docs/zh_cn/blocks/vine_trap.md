# 蔓藤陷阱

![蔓藤陷阱](block:betterwithmods:vine_trap)