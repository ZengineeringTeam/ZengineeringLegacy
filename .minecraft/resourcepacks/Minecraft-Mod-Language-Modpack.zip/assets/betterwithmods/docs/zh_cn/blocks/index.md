# 方块


## 红石设备
 * [方块放置回收器](block_dispenser.md)
 * [探测器](detector.md)
 * [方块更新检测器](buddy_block.md)
 * [火盆](hibachi.md)
 * [镜头聚焦器](lens.md)
 * [泛光灯](light.md)
 * [风铃](wind_chime.md)

## 传动装置
 * [变速箱](wooden_gearbox.md)
 * [木质传动轴](wooden_axle.md)

## 机械装置
 * [磨石](mill.md)
 * [螺杆锯](saw.md)
 * [滤筛漏斗](hopper.md)
 * [风箱](bellows.md)
 * [机械螺杆助力轨道](booster.md)
 * [滑车](pulley.md)
 * [螺杆旋转台](turntable.md)
 * [螺杆泵](screw_pump.md)
 
## 机械动力产生装置
 * [手推曲柄](hand_crank.md) 
 * [风车](windmill.md)
 * [水车](waterwheel.md)        

## 处理
 * [釜锅](cauldron.md)
 * [坩埚](crucible.md)
 * [窑](kiln.md)

## 其他
 * [灵魂陶瓮](soul_urn.md)
 * [熔魂钢块](soulforged_steel_block.md)
 * [炼狱附魔台](infernal_enchanter.md)
 * [十字纹格方块](chopping_block.md)
 * [切割木料](minimized_wood.md)
 * [矿用炸药](mining_charge.md)
 * [装饰方块](decoration.md)
 * [泥土台阶](dirt_slab.md)
 * [吊桶](well_bucket.md)

## TODO
 * [滑车锚](anchor.md)
 * [Anvil](anvil.md)
 * [蔓藤陷阱](vine_trap.md)
 * [Blood Wood](blood_wood.md)
 * [熔魂钢压力板](steel_pressure_plate.md)
 * [培植皿](planter.md)
 * [平台](platform.md)
 * [Minimized Stone](minimized_stone.md)
