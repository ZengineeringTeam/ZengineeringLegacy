# 大麻

![大麻](item:betterwithmods:material@2)
![大麻 种子](block:betterwithmods:hemp)

大麻是一种功能强大的纤维植物，它可以用于制作[麻绳](../items/rope.md)或[大麻布](../items/fabric.md)

大麻种子可以{hcseeds?只能通过用锄头耕地获得:通过打破高草得到}
大麻种子必须种植在水分充足，光线充足的农田，光可以来自阳光或[泛光灯](../blocks/light.md)。
[肥沃的农田](fertile_farmland.md)也可以加速生长。


大麻有两个生长阶段。最好是让植物长到第二阶段，并且只收获顶部的部分大麻，类似于甘蔗。
![](betterwithmods:docs/imgs/hemp-stage-1.png)
![](betterwithmods:docs/imgs/hemp-stage-2.png)
![](https://betterwithmods.github.io/Documentation/imgs/hemp-stage-1.png)
![](https://betterwithmods.github.io/Documentation/imgs/hemp-stage-2.png)
