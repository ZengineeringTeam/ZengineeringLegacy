# 轴

![轴](block:betterwithmods:shaft)

Just a stick in the ground, place torches on it.