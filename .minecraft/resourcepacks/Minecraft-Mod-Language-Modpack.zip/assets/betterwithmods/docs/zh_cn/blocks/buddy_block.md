# 方块更新检测器

![方块更新检测器](block:betterwithmods:buddy_block)

方块更新检测器在其旁边发生方块更新时，在面对的面一个红石信号。
