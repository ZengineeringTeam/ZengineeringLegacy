Better With Mods 添加了许多新的物品和方块，并且增加了许多改变原版Minecraft基本功能的特性。

这个mod分为两个主要部分，核心mod部分和硬核模块系统。
核心mod部分包括:
   * [速成教学](crashcourse/index.md)
   * [方块](blocks/index.md)
   * [物品](items/index.md)

以上部分不能禁用，当然有些可以配置。

硬核模块系统添加了大量的内容，它被分成模块，并进一步分解成一个个功能，所有模块系统都是可配置的。目前拥有的模块：
   * [硬核模块](hardcore/index.md)
   * [Tweaks](tweaks/index.md)
   * [Compat](compat/index.md)
